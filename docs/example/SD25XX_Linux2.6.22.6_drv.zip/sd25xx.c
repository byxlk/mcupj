#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/jiffies.h>
#include <linux/i2c.h>
#include <linux/bcd.h>
#include <linux/rtc.h>
#include <linux/mutex.h>
#include <linux/fs.h>
#include <asm/uaccess.h>

#define DEBUG
#include <linux/device.h>
#undef DEBUG

// SD-25xx Basic Time and Calendar Register definitions
#define SD25xx_SEC					0x00
#define SD25xx_MIN					0x01
#define SD25xx_HOUR				0x02
#define SD25xx_WEEK				0x03
#define SD25xx_DAY					0x04
#define SD25xx_MONTH				0x05
#define SD25xx_YEAR				0x06
#define SD25xx_ALARM_SEC			0x07
#define SD25xx_ALARM_MIN			0x08
#define SD25xx_ALARM_HOUR			0x09
#define SD25xx_ALARM_WEEK			0x0A
#define SD25xx_ALARM_DAY			0x0B
#define SD25xx_ALARM_MONTH		0x0C
#define SD25xx_ALARM_YEAR			0x0D

#define SD25xx_ALARM_EN			0x0E
#       define SD25XX_ALARM_EAY	(1 << 6)
#       define SD25xx_ALARM_EAMO	(1 << 5)
#       define SD25xx_ALARM_EAD	(1 << 4)
#       define SD25xx_ALARM_EAW	(1 << 3)
#       define SD25xx_ALARM_EAH	(1 << 2)
#       define SD25xx_ALARM_EAMN	(1 << 1)
#       define SD25xx_ALARM_EAS	(1 << 0)

#define SD25xx_CTR1				0x0F	/* Control register 1 */
#       define SD25xx_CTR1_WRTC3	(1 << 7)
#       define SD25xx_CTR1_INTAF	(1 << 5)
#       define SD25xx_CTR1_INTDF	(1 << 4)
#       define SD25xx_CTR1_WRTC2	(1 << 2)
#       define SD25xx_CTR1_RTCF	(1 << 0)

#define SD25xx_CTR2				0x10
#       define SD25xx_CTR2_WRTC1	(1 << 7)
#       define SD25xx_CTR2_IM		(1 << 6)
#       define SD25xx_CTR2_INTS1	(1 << 5)
#       define SD25xx_CTR2_INTS0	(1 << 4)
#       define SD25xx_CTR2_FOBAT	(1 << 3)
#       define SD25xx_CTR2_INTDE	(1 << 2)
#       define SD25xx_CTR2_INTAE	(1 << 1)
#       define SD25xx_CTR2_INTFE	(1 << 0)

#define SD25xx_CTR3				0x11
#       define SD25xx_CTR3_ARST	(1 << 7)
#       define SD25xx_CTR3_TDS1	(1 << 5)
#       define SD25xx_CTR3_TDS0	(1 << 4)
#       define SD25xx_CTR3_FS3		(1 << 3)
#       define SD25xx_CTR3_FS2		(1 << 2)
#       define SD25xx_CTR3_FS1		(1 << 1)
#       define SD25xx_CTR3_FS0		(1 << 0)

#define SD25xx_CTR5				0x1A
#       define SD25xx_CTR5_BAT8_VAL	(1 << 7)

#define SD25xx_BAT_VAL				0x1B
#       define SD25xx_CTR5_BAT7_VAL	(1 << 7)
#       define SD25xx_CTR5_BAT6_VAL	(1 << 6)
#       define SD25xx_CTR5_BAT5_VAL	(1 << 5)
#       define SD25xx_CTR5_BAT4_VAL	(1 << 4)
#       define SD25xx_CTR5_BAT3_VAL	(1 << 3)
#       define SD25xx_CTR5_BAT2_VAL	(1 << 2)
#       define SD25xx_CTR5_BAT1_VAL	(1 << 1)
#       define SD25xx_CTR5_BAT0_VAL	(1 << 0)

#define	SD25xx_ID_1st				0x72


#define READ_RTC_INFO 0

enum Freq{F_0Hz, F_32KHz, F_4096Hz, F_1024Hz, F_64Hz, F_32Hz, F_16Hz, F_8Hz,
			F_4Hz, F_2Hz, F_1Hz, F1_2Hz, F1_4Hz, F1_8Hz, F1_16Hz, F_1s};

static unsigned short ignore[]      = { I2C_CLIENT_END };
static unsigned short normal_addr[] = { 0x32, I2C_CLIENT_END }; /* ��ֵַ��7λ */
								
static struct i2c_client_address_data addr_data = {
	.normal_i2c	= normal_addr,  /* Ҫ����S�źź��豸��ַ���õ�ACK�ź�,����ȷ����������豸 */
	.probe		= ignore,
	.ignore		= ignore,
};

static struct i2c_driver SD25xx_driver;


static int major;
static struct class *cls;
struct i2c_client *SD25xx_client;

//----------------------------------------------------------------------
// SD25xx_read_reg()
// reads a SD25xx register (see Register defines)
// See also SD25xx_read_regs() to read multiple registers.
//
//----------------------------------------------------------------------
static int SD25xx_read_reg(struct i2c_client *client, u8 addr)
{
	int ret = i2c_smbus_read_byte_data(client, addr) ;
		
	//check for error
	if (ret < 0) {
		dev_err(&client->dev, "Unable to read register #%d\n", addr);		
	}

	return ret;
}

//----------------------------------------------------------------------
// SD25xx_read_regs()
// reads a specified number of SD25xx registers (see Register defines)
// See also SD25xx_read_reg() to read single register.
//----------------------------------------------------------------------
static int SD25xx_read_regs(struct i2c_client *client, u8 addr,  u8 *values)
{
	int ret = i2c_smbus_read_i2c_block_data(client, addr, values);

	//check for length error
	if (ret == -1) {
		dev_err(&client->dev, "Unable to read \n");
		return ret < 0 ? ret : -EIO;
	}

	return 0;
}

//----------------------------------------------------------------------
// SD25xx_get_time()
// gets the current time from the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_get_time(struct i2c_client *client, struct rtc_time *dt)
{
	//struct SD25xx_data *SD25xx = dev_get_drvdata(dev);
	u8 date[7];
	int err;

	err = SD25xx_read_regs(client, SD25xx_SEC, date);
	if (err)
		return err;

	dev_dbg(&client->dev, "%s: read 0x%02x 0x%02x "
		"0x%02x 0x%02x 0x%02x 0x%02x 0x%02x\n", __func__,
		date[0], date[1], date[2], date[3], date[4], date[5], date[6]);

	dt->tm_sec  = BCD2BIN(date[SD25xx_SEC] & 0x7f);
	dt->tm_min  = BCD2BIN(date[SD25xx_MIN] & 0x7f);
	dt->tm_hour = BCD2BIN(date[SD25xx_HOUR] & 0x3f);
	dt->tm_wday = BCD2BIN(date[SD25xx_WEEK] & 0x7f );
	dt->tm_mday = BCD2BIN(date[SD25xx_DAY] & 0x3f);
	dt->tm_mon  = BCD2BIN(date[SD25xx_MONTH] & 0x1f);
	dt->tm_year = BCD2BIN(date[SD25xx_YEAR]);
	
	if (dt->tm_year < 70)
		dt->tm_year += 100;

	dev_info(&client->dev, "%s: date %d:%d:%d  %d-%d-%d  weekday:%d\n", __func__,
		dt->tm_hour, dt->tm_min, dt->tm_sec, dt->tm_year + 1900, dt->tm_mon,
		dt->tm_mday, dt->tm_wday);

	return rtc_valid_tm(dt);
}

//----------------------------------------------------------------------
// SD25xx_get_ID()
// gets the ID from the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_get_ID(void)
{
	int ret;
	u8 buf[8];
	ret = SD25xx_read_regs(SD25xx_client, SD25xx_ID_1st,  buf);
	dev_info(&SD25xx_client->dev, "%s: %02x-%02x-%02x-%02x-%02x-%02x-%02x-%02x\n",
		__func__,buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7]);
	return ret;
}

//----------------------------------------------------------------------
// SD25xx_get_VBAT()
// gets the the battery voltage from the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_get_VBAT(void)
{
	int ret;
	u8 Vbat_buf[2];
	int Vbat_val;
	ret = SD25xx_read_regs(SD25xx_client, SD25xx_CTR5,  Vbat_buf);
	Vbat_val = (Vbat_buf[0] >> 7) * 256 + Vbat_buf[1];
	dev_info(&SD25xx_client->dev, "%s: SD25xx_VBAT = %d.%d%dV\n",
		__func__,Vbat_val / 100, (Vbat_val % 100) / 10, Vbat_val % 10);
	return ret;
}

//----------------------------------------------------------------------
// i2c_write_reg()
// writes a byte
//----------------------------------------------------------------------
static int i2c_write_byte(struct i2c_client *client, u8 addr, u8 value)
{
	int ret = i2c_smbus_write_byte_data(client, addr, value);

	//check for error
	if (ret)
		dev_err(&client->dev, "Unable to write register #%d\n", addr);

	return ret;
}

//----------------------------------------------------------------------
// SD25xx_write_enable()
// sets SD25xx write enable
//----------------------------------------------------------------------
static void SD25xx_write_enable(void)
{
	int ret;

	ret = SD25xx_read_reg(SD25xx_client, SD25xx_CTR2);
	ret = ret | SD25xx_CTR2_WRTC1;
	i2c_write_byte(SD25xx_client, SD25xx_CTR2, ret);

	ret = SD25xx_read_reg(SD25xx_client, SD25xx_CTR1);
	ret = ret | SD25xx_CTR1_WRTC3 | SD25xx_CTR1_WRTC2;
	i2c_write_byte(SD25xx_client, SD25xx_CTR1, ret);
}

//----------------------------------------------------------------------
// SD25xx_write_disable()
// sets SD25xx write disable
//----------------------------------------------------------------------
static void SD25xx_write_disable(void)
{
	char ret;

	ret = SD25xx_read_reg(SD25xx_client, SD25xx_CTR1);
	ret = ret & (~SD25xx_CTR1_WRTC3) & (~SD25xx_CTR1_WRTC2);
	i2c_write_byte(SD25xx_client, SD25xx_CTR1, ret);

	ret = SD25xx_read_reg(SD25xx_client, SD25xx_CTR2);
	ret = ret & (~SD25xx_CTR2_WRTC1);
	i2c_write_byte(SD25xx_client, SD25xx_CTR2, ret);
}

//----------------------------------------------------------------------
// SD25xx_write_regs()
// writes a specified number of SD25xx registers (see Register defines)
// See also SD25xx_write_reg() to write a single register.
//
//----------------------------------------------------------------------
static int SD25xx_write_regs(struct i2c_client *client, u8 addr, u8 length, u8 *values)
{
	int ret;
	SD25xx_write_enable();
	ret = i2c_smbus_write_i2c_block_data(client, addr, length, values);
	//check for error
	if (ret)
		dev_err(&client->dev, "Unable to write registers #%d..#%d\n", addr, addr + length - 1);
	SD25xx_write_disable();
	return ret;
}

//----------------------------------------------------------------------
// SD25xx_set_time()
// Sets the current time in the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_set_time(struct i2c_client *client, struct rtc_time *dt)
{
	u8 date[7];
	int ret = 0;
	
	date[SD25xx_SEC]   = BIN2BCD(dt->tm_sec);
	date[SD25xx_MIN]   = BIN2BCD(dt->tm_min);
	date[SD25xx_HOUR]  = BIN2BCD(dt->tm_hour) | 0x80;		
	date[SD25xx_WEEK]  = BIN2BCD(dt->tm_wday);
	date[SD25xx_DAY]   = BIN2BCD(dt->tm_mday);
	date[SD25xx_MONTH] = BIN2BCD(dt->tm_mon);
	date[SD25xx_YEAR]  = BIN2BCD(dt->tm_year % 100);

	dev_dbg(&client->dev, "%s: write 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x\n",
		__func__, date[0], date[1], date[2], date[3], date[4], date[5], date[6]);

	ret =  SD25xx_write_regs(client, SD25xx_SEC, 7, date);

	return ret;
}

//----------------------------------------------------------------------
// SD25xx_set_Freq(enum Freq F_Out)
// Sets the Frequency interrupt in the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_set_Freq(enum Freq F_Out)
{
	u8 buf[2];
	int ret;
	
	buf[0] = SD25xx_CTR2_WRTC1|SD25xx_CTR2_INTS1|SD25xx_CTR2_INTFE;
	buf[1] = F_Out;
	ret =  SD25xx_write_regs(SD25xx_client, SD25xx_CTR2, 2, buf);

	return ret;
}

//----------------------------------------------------------------------
// SD25xx_set_alarm_time(struct rtc_time *t)
// Sets the AlarmTime in the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_set_alarm_time(struct rtc_time *t)
{
	u8 date[7];
	int ret = 0;
	
	date[0] = BIN2BCD(t->tm_sec);
	date[1] = BIN2BCD(t->tm_min);
	date[2] = BIN2BCD(t->tm_hour);		
	date[3] = BIN2BCD(t->tm_wday);
	date[4] = BIN2BCD(t->tm_mday);
	date[5] = BIN2BCD(t->tm_mon);
	date[6] = BIN2BCD(t->tm_year % 100);

	ret =  SD25xx_write_regs(SD25xx_client, SD25xx_ALARM_SEC, 7, date);

	return ret;
}

//----------------------------------------------------------------------
// SD25xx_set_alarm_enable(struct rtc_time *t)
// Sets the AlarmTime in the SD25xx registers
//
//----------------------------------------------------------------------
static int SD25xx_set_alarm_enable(u8 dat)
{
	u8 buf;
	int ret;
	ret =  SD25xx_write_regs(SD25xx_client, SD25xx_ALARM_EN, 1, &dat);
	buf = SD25xx_CTR2_WRTC1 | SD25xx_CTR2_INTS0 | SD25xx_CTR2_INTAE;
	ret =  SD25xx_write_regs(SD25xx_client, SD25xx_CTR2, 1, &buf);

	return ret;
}

static ssize_t SD25xx_read(struct file *file, char __user *buf, size_t size, loff_t * offset)
{
	u8 address;
	u8 values[8];
	u8 str[] = {"ok"};
	int ret;
	struct rtc_time SD25xx_time_info;
	
	if (size != 1)
		return -EINVAL;
	
	copy_from_user(&address, buf, 1);
	if (address == READ_RTC_INFO)
	{
		ret = SD25xx_get_time(SD25xx_client, &SD25xx_time_info);
		SD25xx_get_ID();
		SD25xx_get_VBAT();
	}
	else
	{
		ret = SD25xx_read_regs(SD25xx_client, address, values);
		printk("%x-%x-%x-%x-%x-%x-%x-%x\n", values[0], values[1] , values[2],
	values[3], values[4], values[5], values[6], values[7]);
		}
	copy_to_user(buf, &str, 2);
	return ret;
}

static ssize_t SD25xx_write(struct file *file, const char __user *buf, size_t size, loff_t *offset)
{
	unsigned char val[size];
	int ret;
	struct rtc_time t;
	
	/* address = buf[0] 
	 * data    = buf[1]
	 */
	
	copy_from_user(val, buf, size);
	if(val[0] == 0)
	{
		if(size != 8)
		{
			dev_err(&SD25xx_client->dev, "too few arguments to write Real_Time Clock, Please enter seven RTC arguments \n");
			return -EINVAL;
		}
		t.tm_sec = val[1];
		t.tm_min = val[2];
		t.tm_hour = val[3];
		t.tm_wday = val[4];
		t.tm_mday = val[5];
		t.tm_mon = val[6];
		t.tm_year = val[7];

		ret = SD25xx_set_time(SD25xx_client, &t);
		}
	else
		ret = SD25xx_write_regs(SD25xx_client, val[0], size - 1, &val[1]);

	return ret;
}

static struct file_operations SD25xx_fops = {
	.owner = THIS_MODULE,
	.read  = SD25xx_read,
	.write = SD25xx_write,
};

static int SD25xx_detect(struct i2c_adapter *adapter, int address, int kind)
{	
	printk("SD25xx_detect\n");

	SD25xx_client = kzalloc(sizeof(struct i2c_client), GFP_KERNEL);
	SD25xx_client->addr    = address;
	SD25xx_client->adapter = adapter;
	SD25xx_client->driver  = &SD25xx_driver;
	strcpy(SD25xx_client->name, "SD25xx");
	i2c_attach_client(SD25xx_client);
	
	major = register_chrdev(0, "SD25xx", &SD25xx_fops);

	cls = class_create(THIS_MODULE, "SD25xx");
	class_device_create(cls, NULL, MKDEV(major, 0), NULL, "SD25xx"); /* /dev/SD25xx */
	
	return 0;
}

static int SD25xx_attach(struct i2c_adapter *adapter)
{
	return i2c_probe(adapter, &addr_data, SD25xx_detect);
}

static int SD25xx_detach(struct i2c_client *client)
{
	printk("SD25xx_detach\n");
	class_device_destroy(cls, MKDEV(major, 0));
	class_destroy(cls);
	unregister_chrdev(major, "SD25xx");

	i2c_detach_client(client);
	kfree(i2c_get_clientdata(client));

	return 0;
}

static struct i2c_driver SD25xx_driver = {
	.driver = {
		.name	= "SD25xx",
	},
	.attach_adapter = SD25xx_attach,
	.detach_client  = SD25xx_detach,
};

static int SD25xx_init(void)
{
	i2c_add_driver(&SD25xx_driver);
	return 0;
}

static void SD25xx_exit(void)
{
	i2c_del_driver(&SD25xx_driver);
}

module_init(SD25xx_init);
module_exit(SD25xx_exit);

MODULE_LICENSE("GPL");


