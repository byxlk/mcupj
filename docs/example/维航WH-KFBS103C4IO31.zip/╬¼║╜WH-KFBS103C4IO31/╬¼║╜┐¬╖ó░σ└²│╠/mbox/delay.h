#ifndef __DELAY_H
#define __DELAY_H 			   
#include "stm32f10x.h" 
static struct Time
{
    volatile uint32_t msPeriod;	// �����ڵ�ʱ�䣬ms��
    uint32_t ticksPerUs;  		// ÿus���ڵĵδ����
    uint32_t ticksPerMs;  		// ÿms���ڵĵδ����
    uint32_t msPerPeriod; 		// ÿ���ڵ�ms��
}time;
#define Loop_Begin(time_ms) \
		{\
			static uint32_t target = 0;\
			if(target <= time_nowms())\
			{\
				target = time_nowms() + time_ms;
#define Loop_End() \
			}\
		}
void delay_init(void);
void delay_ms(u16 nms);
void delay_us(u32 nus);
void leon_init(void);
uint64_t time_nowus(void);
uint32_t time_nowms(void);
void SysRestart(void); //ϵͳ����
#endif





























