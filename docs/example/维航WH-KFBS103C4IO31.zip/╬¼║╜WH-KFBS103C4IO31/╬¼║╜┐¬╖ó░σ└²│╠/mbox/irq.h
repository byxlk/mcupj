#ifndef __IRQ_H
#define __IRQ_H
#include "stm32f10x.h"
#define TIMER_HZ 10 //��ʱ���ص������ĸ���
extern void INTX_DISABLE(void);
extern void INTX_ENABLE(void);
extern void (*callback_time1[TIMER_HZ])(void);
extern void (*callback_time2[TIMER_HZ])(void);
extern void (*callback_time3[TIMER_HZ])(void);
extern void (*callback_time4[TIMER_HZ])(void);

extern uint16_t tim1_count,tim2_count,tim3_count,tim4_count;

#endif

