/*
���ߣ�mbees
�汾��V1.0
ʱ�䣺2016.08.08
�������˹���û�б���˾��������������ҵ��;�����򽫸��������Ρ�
*/
#include "oled.h"
#include "stdlib.h"
#include "oledfont.h"  	
#include "stdarg.h"
#include "stdio.h"
extern "C"
{
#include "delay.h"	
};
OLED::OLED(GPIO *sclkPin,GPIO *sdinPin,char address)
{
	this->sclkPin=sclkPin;
	this->sdinPin=sdinPin;
    this->_address=address;
}

OLED::OLED(GPIO *sclkPin,GPIO *sdinPin,GPIO *rstPin,GPIO *dcPin)
{
	this->sclkPin=sclkPin;
	this->sdinPin=sdinPin;
	this->rstPin=rstPin;
	this->dcPin=dcPin;
}

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����
#define SIZE 8
#define XLevelL		0x00
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64

//OLED���Դ�
//��Ÿ�ʽ����.
//[0]0 1 2 3 ... 127	
//[1]0 1 2 3 ... 127	
//[2]0 1 2 3 ... 127	
//[3]0 1 2 3 ... 127	
//[4]0 1 2 3 ... 127	
//[5]0 1 2 3 ... 127	
//[6]0 1 2 3 ... 127	
//[7]0 1 2 3 ... 127 			   
/**********************************************
//IIC Start
**********************************************/
/**********************************************
//IIC Start
**********************************************/
void OLED::Start()
{
	this->sclkPin->set();
	this->sdinPin->set();
	this->sdinPin->reset();
	this->sclkPin->reset();
}

/**********************************************
//IIC Stop
**********************************************/
void OLED::Stop()
{
	this->sclkPin->set();
//	this->sdinPin->reset();
	this->sdinPin->reset();
	this->sdinPin->set();
	
}

void OLED::WaitAck()
{
	this->sclkPin->set();
	this->sclkPin->reset();
}
/**********************************************
// IIC Write byte
**********************************************/

void OLED::WriteByte(unsigned char IIC_Byte)
{
	unsigned char i;
	unsigned char m,da;
	da=IIC_Byte;
	this->sclkPin->reset();
	for(i=0;i<8;i++)		
	{
	    m=da;
		m=m&0x80;
		if(m==0x80)
		{this->sdinPin->set();}
		else this->sdinPin->reset();
			da=da<<1;
		this->sclkPin->set();
		this->sclkPin->reset();
		}


}
/**********************************************
// IIC Write Command
**********************************************/
void OLED::WriteCommand(unsigned char IIC_Command)
{
	#if OLED_MODE == 0
        OLED::Start();
        OLED::WriteByte(this->_address);            //Slave address,SA0=0
        OLED::WaitAck();	
        OLED::WriteByte(0x00);			//write command
        OLED::WaitAck();	
        OLED::WriteByte(IIC_Command); 
        OLED::WaitAck();	
        OLED::Stop();
	#else
		unsigned char i;
		this->dcPin->reset();
		for(i = 0; i < 8; i++) //����һ����λ����
		{
			if((IIC_Command << i) & 0x80)
			{
				this->sdinPin->set();
			}
			else
			{
			   this->sdinPin->reset();
			}
			delay_us(1);
			this->sclkPin->reset();
			delay_us(1);
			this->sclkPin->set();
		}
	#endif	
	
}
/**********************************************
// IIC Write Data
**********************************************/
void OLED::WriteData(unsigned char IIC_Data)
{
	#if OLED_MODE == 0
        OLED::Start();
        OLED::WriteByte(this->_address);			 //Slave address,SA0=0
        OLED::WaitAck();	
        OLED::WriteByte(0x40);			//write data
        OLED::WaitAck();	
        OLED::WriteByte(IIC_Data);
        OLED::WaitAck();	
        OLED::Stop();
	#else
		unsigned char i;
		this->dcPin->set();
		for(i = 0; i < 8; i++) 
		{
			if((IIC_Data << i) & 0x80)
			{
				this->sdinPin->set();
			}
			else
			{
			   this->sdinPin->reset();
			}
			delay_us(1);
			this->sclkPin->reset();
			delay_us(1);
			this->sclkPin->set();
		}
	#endif	
}
void OLED::WRByte(unsigned dat,unsigned cmd)
{
	if(cmd)
	{
      OLED::WriteData(dat);
    }
	else {
      OLED::WriteCommand(dat);
		
	}
}


/********************************************
// OLED::FillPicture
********************************************/
void OLED::FillPicture(unsigned char fill_Data)
{
	unsigned char m,n;
	for(m=0;m<8;m++)
	{
		OLED::WRByte(0xb0+m,0);		//page0-page1
		OLED::WRByte(0x00,0);		//low column start address
		OLED::WRByte(0x10,0);		//high column start address
		for(n=0;n<128;n++)
			{
				OLED::WRByte(fill_Data,1);
			}
	}
}


/***********************Delay****************************************/
void Delay_50ms(unsigned int Del_50ms)
{
	unsigned int m;
	for(;Del_50ms>0;Del_50ms--)
		for(m=6245;m>0;m--);
}

void Delay_1ms(unsigned int Del_1ms)
{
	unsigned char j;
	while(Del_1ms--)
	{	
		for(j=0;j<123;j++);
	}
}

//��������
void OLED::SetPos(unsigned char x, unsigned char y) 
{ 	OLED::WRByte(0xb0+y,OLED_CMD);
	OLED::WRByte(((x&0xf0)>>4)|0x10,OLED_CMD);
	OLED::WRByte((x&0x0f),OLED_CMD); 
}   	  
//����OLED��ʾ    
void OLED::DisplayOn(void)
{
	OLED::WRByte(0X8D,OLED_CMD);  //SET DCDC����
	OLED::WRByte(0X14,OLED_CMD);  //DCDC ON
	OLED::WRByte(0XAF,OLED_CMD);  //DISPLAY ON
}
//�ر�OLED��ʾ     
void OLED::DisplayOff(void)
{
	OLED::WRByte(0X8D,OLED_CMD);  //SET DCDC����
	OLED::WRByte(0X10,OLED_CMD);  //DCDC OFF
	OLED::WRByte(0XAE,OLED_CMD);  //DISPLAY OFF
}		   			 
//��������,������,������Ļ�Ǻ�ɫ��!��û����һ��!!!	  
void OLED::Clear(void)  
{  
	u8 i,n;		    
	for(i=0;i<8;i++)  
	{  
		OLED::WRByte (0xb0+i,OLED_CMD);    //����ҳ��ַ��0~7��
		OLED::WRByte (0x00,OLED_CMD);      //������ʾλ�á��е͵�ַ
		OLED::WRByte (0x10,OLED_CMD);      //������ʾλ�á��иߵ�ַ   
		for(n=0;n<128;n++)OLED::WRByte(0,OLED_DATA); 
	} //������ʾ
}
void OLED::On(void)  
{  
	u8 i,n;		    
	for(i=0;i<8;i++)  
	{  
		OLED::WRByte (0xb0+i,OLED_CMD);    //����ҳ��ַ��0~7��
		OLED::WRByte (0x00,OLED_CMD);      //������ʾλ�á��е͵�ַ
		OLED::WRByte (0x10,OLED_CMD);      //������ʾλ�á��иߵ�ַ   
		for(n=0;n<128;n++)OLED::WRByte(1,OLED_DATA); 
	} //������ʾ
}
//��ָ��λ����ʾһ���ַ�,���������ַ�
//x:0~127
//y:0~63
//mode:0,������ʾ;1,������ʾ				 
//size:ѡ������ 16/12 
void OLED::ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size)
{      	
	unsigned char c=0,i=0;	
		c=chr-' ';//�õ�ƫ�ƺ��ֵ			
		if(x>Max_Column-1){x=0;y=y+2;}
		if(Char_Size ==16)
			{
			OLED::SetPos(x,y);	
			for(i=0;i<8;i++)
			OLED::WRByte(F8X16[c*16+i],OLED_DATA);
			OLED::SetPos(x,y+1);
			for(i=0;i<8;i++)
			OLED::WRByte(F8X16[c*16+i+8],OLED_DATA);
			}
			else {	
				OLED::SetPos(x,y);
				for(i=0;i<6;i++)
				OLED::WRByte(F6x8[c][i],OLED_DATA);
				
			}
}
//m^n����
u32 oled_pow(u8 m,u8 n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}				  
//��ʾ2������
//x,y :�������	 
//len :���ֵ�λ��
//size:�����С
//mode:ģʽ	0,���ģʽ;1,����ģʽ
//num:��ֵ(0~4294967295);	 		  
void OLED::ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size2)
{         	
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/oled_pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				OLED::ShowChar(x+(size2/2)*t,y,' ',size2);
				continue;
			}else enshow=1; 
		 	 
		}
	 	OLED::ShowChar(x+(size2/2)*t,y,temp+'0',size2); 
	}
} 
//��ʾһ���ַ��Ŵ�
void OLED::ShowString(u8 x,u8 y,const char *chr,u8 Char_Size)
{
	unsigned char j=0;
	while (chr[j]!='\0')
		{	ShowChar(x,y,chr[j],Char_Size);
			x+=8;
		if(x>120){x=0;y+=2;}
			j++;
	}
}
//��ʾ����
void OLED::ShowCHinese(u8 x,u8 y,u8 no)
{      			    
	u8 t,adder=0;
	OLED::SetPos(x,y);	
    for(t=0;t<16;t++)
		{
				OLED::WRByte(Hzk[2*no][t],OLED_DATA);
				adder+=1;
     }	
		OLED::SetPos(x,y+1);	
    for(t=0;t<16;t++)
			{	
				OLED::WRByte(Hzk[2*no+1][t],OLED_DATA);
				adder+=1;
      }					
}
/***********������������ʾ��ʾBMPͼƬ128��64��ʼ������(x,y),x�ķ�Χ0��127��yΪҳ�ķ�Χ0��7*****************/
void OLED::DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[])
{ 	
 unsigned int j=0;
 unsigned char x,y;
  
  if(y1%8==0) y=y1/8;      
  else y=y1/8+1;
	for(y=y0;y<y1;y++)
	{
		OLED::SetPos(x0,y);
    for(x=x0;x<x1;x++)
	    {      
	    	OLED::WRByte(BMP[j++],OLED_DATA);	    	
	    }
	}
} 

//��ʼ��SSD1306					    
void OLED::Begin(void)
{ 	
	this->sclkPin->mode(OUTPUT_PP);
	this->sdinPin->mode(OUTPUT_PP);
	#if OLED_MODE == 1
	this->rstPin->mode(OUTPUT_PP);
	this->dcPin->mode(OUTPUT_PP);
	delay_ms(10);
	this->sclkPin->set();
	this->rstPin->reset();
	delay_ms(50);
	this->rstPin->set();
    delay_ms(800);
	WRByte(0xae,OLED_CMD);//--turn off oled panel
    WRByte(0x00,OLED_CMD);//---set low column address
    WRByte(0x10,OLED_CMD);//---set high column address
    WRByte(0x40,OLED_CMD);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
    WRByte(0x81,OLED_CMD);//--set contrast control register
    WRByte(0xcf,OLED_CMD); // Set SEG Output Current Brightness
    WRByte(0xa0,OLED_CMD);//--Set SEG/Column Mapping     0xa0???? 0xa1??
    WRByte(0xc0,OLED_CMD);//Set COM/Row Scan Direction   0xc0???? 0xc8??
    WRByte(0xa6,OLED_CMD);//--set normal display
    WRByte(0xa8,OLED_CMD);//--set multiplex ratio(1 to 64)
    WRByte(0x3f,OLED_CMD);//--1/64 duty
    WRByte(0xd3,OLED_CMD);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
    WRByte(0x00,OLED_CMD);//-not offset
    WRByte(0xd5,OLED_CMD);//--set display clock divide ratio/oscillator frequency
    WRByte(0x80,OLED_CMD);//--set divide ratio, Set Clock as 100 Frames/Sec
    WRByte(0xd9,OLED_CMD);//--set pre-charge period
    WRByte(0xf1,OLED_CMD);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
    WRByte(0xda,OLED_CMD);//--set com pins hardware configuration
    WRByte(0x12,OLED_CMD);
    WRByte(0xdb,OLED_CMD);//--set vcomh
    WRByte(0x40,OLED_CMD);//Set VCOM Deselect Level
    WRByte(0x20,OLED_CMD);//-Set Page Addressing Mode (0x00/0x01/0x02)
    WRByte(0x02,OLED_CMD);//
    WRByte(0x8d,OLED_CMD);//--set Charge Pump enable/disable
    WRByte(0x14,OLED_CMD);//--set(0x10) disable
    WRByte(0xa4,OLED_CMD);// Disable Entire Display On (0xa4/0xa5)
    WRByte(0xa6,OLED_CMD);// Disable Inverse Display On (0xa6/a7)
    WRByte(0xaf,OLED_CMD);//--turn on oled panel
	#else
		OLED::WRByte(0xAE,OLED_CMD);//--display off
		OLED::WRByte(0x00,OLED_CMD);//---set low column address
		OLED::WRByte(0x10,OLED_CMD);//---set high column address
		OLED::WRByte(0x40,OLED_CMD);//--set start line address  
		OLED::WRByte(0xB0,OLED_CMD);//--set page address
		OLED::WRByte(0x81,OLED_CMD); // contract control
		OLED::WRByte(0xFF,OLED_CMD);//--128   
		OLED::WRByte(0xA1,OLED_CMD);//set segment remap 
		OLED::WRByte(0xA6,OLED_CMD);//--normal / reverse
		OLED::WRByte(0xA8,OLED_CMD);//--set multiplex ratio(1 to 64)
		OLED::WRByte(0x3F,OLED_CMD);//--1/32 duty
		OLED::WRByte(0xC8,OLED_CMD);//Com scan direction
		OLED::WRByte(0xD3,OLED_CMD);//-set display offset
		OLED::WRByte(0x00,OLED_CMD);//
		OLED::WRByte(0xD5,OLED_CMD);//set osc division
		OLED::WRByte(0x80,OLED_CMD);//
		OLED::WRByte(0xD8,OLED_CMD);//set area color mode off
		OLED::WRByte(0x05,OLED_CMD);//
		OLED::WRByte(0xD9,OLED_CMD);//Set Pre-Charge Period
		OLED::WRByte(0xF1,OLED_CMD);//
		WRByte(0xDA,OLED_CMD);//set com pin configuartion
		WRByte(0x12,OLED_CMD);//
		WRByte(0xDB,OLED_CMD);//set Vcomh
		WRByte(0x30,OLED_CMD);//
		WRByte(0x8D,OLED_CMD);//set charge pump enable
		WRByte(0x14,OLED_CMD);//
		WRByte(0xAF,OLED_CMD);//--turn on oled panel
	#endif	
}  
void OLED::Printf(unsigned char  x, unsigned char  y,const char *fmt, ...)
{
    va_list args;
    uint8_t length;
    uint8_t i,j,c;
    static char log_buf[128];
    va_start(args, fmt);
    length = vsnprintf(log_buf, sizeof(log_buf) - 1, fmt, args);
    if (length > 128) length = 128;
    for(i = 0; i < length; i ++)
    {
        c = log_buf[i] - 32;
        if( x > 120 )
        {
            x = 0;
            y++;
        }
        SetPos(x, y);
        for(j = 0; j < 6; j++)
        {
            WriteData(F6x8[c][j]);
        }
        x += 6;
        j++;
    }
    va_end(args);
}
