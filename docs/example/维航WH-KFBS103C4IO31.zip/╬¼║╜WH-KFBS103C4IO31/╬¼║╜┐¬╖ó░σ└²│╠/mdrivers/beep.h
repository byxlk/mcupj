#ifndef __BEEP_H
#define __BEEP_H	 
#include "io.h"
typedef enum
{
    ON        = 0x0,//��
    OFF       = 0x01,//��
} MODE;
class BEEP
{
	public:
	BEEP(GPIO *pin);
	void Begin(void);//��ʼ��
	void Switch(MODE state);
	void Toggle(void);
	private:
	GPIO *pin;
};				    
#endif
