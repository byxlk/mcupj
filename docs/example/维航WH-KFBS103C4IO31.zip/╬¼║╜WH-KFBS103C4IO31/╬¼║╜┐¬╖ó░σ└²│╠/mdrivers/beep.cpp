#include "beep.h"

BEEP::BEEP(GPIO *pin)
{
	this->pin=pin;
}
void BEEP::Begin(void)
{
	this->pin->mode(OUTPUT_PP);
}
void BEEP::Switch(MODE state)
{
	if(state==0x00)
	{
		this->pin->set();
	}
	else
	{
	  this->pin->reset();
	}
}
//Leo: Change toggle to Toggle;
void BEEP::Toggle(void)
{
	this->pin->toggle();
}
 

