
#include "includes.h"


 unsigned char   xdata dis_code1[16]="    avccd       ";
 unsigned char   xdata dis_code2[16]="abdcefghigklmnop";

/*
///////////////////////////////////////////////////////////
void delay_ms(unsigned int  timer)
{unsigned char  i=0;
	while (timer--)
	for(i=600;i>0;i--);
}
void Delay15us()		//@12.000MHz
{
	unsigned char i;

	_nop_();
	_nop_();
	i = 42;
	while (--i);
}

void wait()
{
	RS=0;
	RW=1;
	EN=0;
	EN=1;
	P2=0XFF;
//	delay_ms(50);

	while(P2&0X80) ;
	EN=0;

}
void write_lcd_cmd(unsigned char  cmd)
{
	wait();
	RS=0;
	RW=0;
	EN=0;
	_nop_();
	EN=1;
	P2=cmd;
	delay_ms(5);
	EN=0;
}
void write_lcd_data(unsigned char  dat)
{ 
	wait();
	RS=1;
	RW=0;
	EN=0;
	_nop_();
	EN=1;
	delay_ms(5);
	P2=dat;

	EN=0;
}
void lcd_init()
{
	EN=0;
	write_lcd_cmd(0x38);
	delay_ms(1);
	write_lcd_cmd(0x06);
	delay_ms(1);
	write_lcd_cmd(0x0C);
	delay_ms(1);
	write_lcd_cmd(0x01);
	delay_ms(1);
}
void lcd_display()
{
		unsigned char  i=0;

	write_lcd_cmd(0x80);
	for(i=0;i<16;i++)
	{
		if( dis_code1[i]==0)
			 dis_code1[i]=' ';
		write_lcd_data(dis_code1[i]) ;
	}
	write_lcd_cmd(0x80+0x40);
	for(i=0;i<16;i++)
	{
		if( dis_code2[i]==0)
			 dis_code2[i]=' ';

		write_lcd_data(dis_code2[i]);
	}
	
}
void lcd_piontFlash()
{
		static flag1=0;

	write_lcd_cmd(0x8f);
	if(flag1)
		write_lcd_data(0xff) ;
	else
		write_lcd_data(' ') ;
	flag1=~flag1;
	
}
void IntToStr(unsigned long t, unsigned char *str) 
{
	unsigned char a[9]; char i;  
	a[0]=(t/10000000)%10;         //ȡ������ֵ������    
	a[1]=0X2e-0x30;                                     	
	
	a[2]=(t/1000000)%10;                                     	
	a[3]=(t/100000)%10;                                      	
	a[4]=(t/10000)%10;                                       	
	a[5]=(t/1000)%10;                                        	
	a[6]=(t/100)%10;         //ȡ������ֵ������         	
	a[7]=(t/10)%10;                                     	
	a[8]=(t/1)%10;                                      	
                                                      
	for(i=0; i<9; i++)         //ת��ASCII��   
		 a[i] +=0x30;
	for(i=0; i<9; i++)                                       	
		{ *str=a[i]; str++; }  //������Ч������           	
} 
/////////////////////////////////////////////////////////////////
void delay(unsigned int i)
{
    unsigned char j;
    for(i; i > 0; i--)
        for(j = 200; j > 0; j--);
}*/


void wait()
{
	RS=0;
	RW=1;
	EN=0;
	EN=1;
	P2=0XFF;
	OSTimeDlyHMSM(0,0,0,100);
	
//	while(P2&0X80) ;
	EN=0;

}
void write_lcd_cmd(unsigned char  cmd)
{
	wait();
	RS=0;
	RW=0;
	EN=0;
	_nop_();
	EN=1;
	P2=cmd;
	OSTimeDly (1);
	EN=0;
}
void write_lcd_data(unsigned char  dat)
{ 
	wait();
	RS=1;
	RW=0;
	EN=0;
	_nop_();
	EN=1;
//	OSTimeDly (1);
	P2=dat;

	EN=0;
}
void lcd_init()
{
	EN=0;
	write_lcd_cmd(0x38);
	OSTimeDly (1);
	write_lcd_cmd(0x06);
	OSTimeDly (1);
	write_lcd_cmd(0x0C);
	OSTimeDly (1);
	write_lcd_cmd(0x01);
	OSTimeDly (1);
}
void lcd_display()
{
		unsigned char  i=0;

	write_lcd_cmd(0x80);
	for(i=0;i<16;i++)
	{
		if( dis_code1[i]==0)
			 dis_code1[i]=' ';
		write_lcd_data(dis_code1[i]) ;
	}
	write_lcd_cmd(0x80+0x40);
	for(i=0;i<16;i++)
	{
		if( dis_code2[i]==0)
			 dis_code2[i]=' ';

		write_lcd_data(dis_code2[i]);
	}
	
}
void lcd_piontFlash()
{
		static flag1=0;

	write_lcd_cmd(0x8f);
	if(flag1)
		write_lcd_data(0xff) ;
	else
		write_lcd_data(' ') ;
	flag1=~flag1;
	
}
void IntToStr(unsigned long t, unsigned char *str) 
{
	unsigned char a[9]; char i;  
	a[0]=(t/10000000)%10;         //ȡ������ֵ������    
	a[1]=0X2e-0x30;                                     	
	
	a[2]=(t/1000000)%10;                                     	
	a[3]=(t/100000)%10;                                      	
	a[4]=(t/10000)%10;                                       	
	a[5]=(t/1000)%10;                                        	
	a[6]=(t/100)%10;         //ȡ������ֵ������         	
	a[7]=(t/10)%10;                                     	
	a[8]=(t/1)%10;                                      	
                                                      
	for(i=0; i<9; i++)         //ת��ASCII��   
		 a[i] +=0x30;
	for(i=0; i<9; i++)                                       	
		{ *str=a[i]; str++; }  //������Ч������           	
} 
