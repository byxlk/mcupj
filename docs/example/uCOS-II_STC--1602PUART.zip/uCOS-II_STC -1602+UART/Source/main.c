/* ������uCOS-II �汾Ϊ2.51*/  

#include "includes.h"
#include "test1.h"
#include <string.h>

OS_EVENT *Display_Semp;
sbit LED1=P1^0;

sbit LED2=P1^1;  

//sbit key1=P1^2;

OS_STK xdata Task1Stk[MaxStkSize+1];

OS_STK xdata Task2Stk[MaxStkSize+1];
OS_STK xdata Task3Stk[MaxStkSize+1];


OS_EVENT* xdata FirstSem;

INT8U err;

void Task1(void *ppdata) reentrant
{
	ppdata = ppdata;
	    lcd_init();

	while(1)
	{
		lcd_display();
		OSTimeDlyHMSM(0,0,1,500);	
    }
}



void Task2(void *ppdata) reentrant
{

	ppdata=ppdata;

	for(;;)
    {
 PrintString1("STC15F2K60S2 UART1 Test Prgramme!\r\n");				

		OSTimeDlyHMSM(0,0,0,500);	
    }    
}

void lcd_display1(void *ppdata) reentrant
{

	ppdata=ppdata;

	for(;;)
    {

		OSTimeDlyHMSM(0,0,0,500);	
    }    
}
void Task0(void *ppdata) reentrant
{

	
}

void main(void)
{

	OSInit();
	InitHardware();
    Display_Semp=OSSemCreate(0);//����һ���ź���
	OSTaskCreate(Task1,(void*)0,&Task1Stk[0],2);   //��ʾ

	OSTaskCreate(Task2,(void*)0,&Task2Stk[0],3);   //adc�ɼ�

//	OSTaskCreate(lcd_display1,(void*)0,&Task3Stk[0],7);  //��ʾ

//    OSTaskCreate(Task0,(void*)0,&Task1Stk[0],1);  


	OSStart();

}
