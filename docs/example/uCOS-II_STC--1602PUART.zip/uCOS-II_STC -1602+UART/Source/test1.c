#include "test1.h"
#include	"STC15Fxxxx.H"
#include <string.h>
#include <stdio.h>
#include<intrins.h>

 #define uint unsigned int 
#define uchar unsigned char 

uchar  xdata dis_code1[16]="                ";
uchar  xdata dis_code2[16]="                ";
uchar speed_mode =0;
uchar gain_mode =AD7190_CONF_GAIN_1;
uchar vote_range =VOT_2000MV;
unsigned long speed_x=0;
    unsigned char speed1=0;

                          
//sfr SPDAT       =   0xcf;       //SPI���ݼĴ���                           

 ////////////////////////////////
uint d,time,g,s,b;
sbit RS=P3^5;
sbit RW=P3^6;
sbit EN=P3^7;

sbit key1 = P3^2;
sbit key2 = P3^3;
sbit key3 = P3^4;
sbit key4 = P5^4;
sbit key5 = P1^7;
sbit key6 = P1^6;
sbit key7 = P5^5;
sbit key8 = P1^0;

uchar  dis_code1[16];
uchar  dis_code2[16];
uchar speed_mode ;
uchar gain_mode ;
uchar vote_range;
unsigned long speed_x;
    unsigned char speed1;



sbit  AD7190_RDY = P1^4;
#define AD7190_RDY_STATE       AD7190_RDY
sbit  ADI_CS = P1^2;
#define		ADI_CS_LOW		ADI_CS=0;
#define		ADI_CS_HIGH		ADI_CS=1;

///////////////////////////////////////////////////////////
void delay_ms(uint timer)
{uchar i=0;
	while (timer--)
	for(i=600;i>0;i--);
}
void Delay15us()		//@12.000MHz
{
	unsigned char i;

	_nop_();
	_nop_();
	i = 42;
	while (--i);
}

void wait()
{
	RS=0;
	RW=1;
	EN=0;
	EN=1;
	P2=0XFF;
	while(P2&0X80) ;
	EN=0;

}
void write_lcd_cmd(uchar cmd)
{
	wait();
	RS=0;
	RW=0;
	EN=0;
	_nop_();
	EN=1;
	P2=cmd;
	delay_ms(5);
	EN=0;
}
void write_lcd_data(uchar dat)
{ 
	wait();
	RS=1;
	RW=0;
	EN=0;
	_nop_();
	EN=1;
	delay_ms(5);
	P2=dat;

	EN=0;
}
void lcd_init()
{
	EN=0;
	write_lcd_cmd(0x38);
	delay_ms(1);
	write_lcd_cmd(0x06);
	delay_ms(1);
	write_lcd_cmd(0x0C);
	delay_ms(1);
	write_lcd_cmd(0x01);
	delay_ms(1);
}
void lcd_display()
{
		uchar i=0;

	write_lcd_cmd(0x80);
	for(i=0;i<16;i++)
	{
		if( dis_code1[i]==0)
			 dis_code1[i]=' ';
		write_lcd_data(dis_code1[i]) ;
	}
	write_lcd_cmd(0x80+0x40);
	for(i=0;i<16;i++)
	{
		if( dis_code2[i]==0)
			 dis_code2[i]=' ';

		write_lcd_data(dis_code2[i]);
	}
	
}
void lcd_piontFlash()
{
		static flag1=0;

	write_lcd_cmd(0x8f);
	if(flag1)
		write_lcd_data(0xff) ;
	else
		write_lcd_data(' ') ;
	flag1=~flag1;
	
}
void IntToStr(unsigned long t, unsigned char *str) 
{
	unsigned char a[9]; char i;  
	a[0]=(t/10000000)%10;         //ȡ������ֵ������    
	a[1]=0X2e-0x30;                                     	
	
	a[2]=(t/1000000)%10;                                     	
	a[3]=(t/100000)%10;                                      	
	a[4]=(t/10000)%10;                                       	
	a[5]=(t/1000)%10;                                        	
	a[6]=(t/100)%10;         //ȡ������ֵ������         	
	a[7]=(t/10)%10;                                     	
	a[8]=(t/1)%10;                                      	
                                                      
	for(i=0; i<9; i++)         //ת��ASCII��   
		 a[i] +=0x30;
	for(i=0; i<9; i++)                                       	
		{ *str=a[i]; str++; }  //������Ч������           	
} 
/////////////////////////////////////////////////////////////////
void delay(unsigned int i)
{
    unsigned char j;
    for(i; i > 0; i--)
        for(j = 200; j > 0; j--);
}
/////////////////////////////////////////////////////////////////
unsigned long process(unsigned long ch,unsigned long speed_mode ,unsigned long filter,unsigned char times)   //ͨ�� ���ٶ� ,�˲���������
{
	unsigned long oldRegValue = 0x0;
	unsigned long newRegValue = 0x0;
 	unsigned long resulttemp=0;  //

    if(vote_range ==VOT_20MV)
	{
		strcpy(VOT_RANGE_DISP,"20mV ");
//		oldRegValue = AD7190_GetRegisterValue(AD7190_REG_MODE,3, 1);   //�����ٶ�
		switch (speed_mode)
		{
			case SPEED_MODE_H: 
				{speed_x = 1;break; }
			case SPEED_MODE_M:
				{speed_x = 96;break; }
			case SPEED_MODE_L:
				{speed_x = 1023;break; }
			default:
				{speed_x = speed_mode;break; }
		}

//		AD7190_SetRegisterValue(AD7190_REG_MODE,newRegValue,3, 1);

		gain_mode = AD7190_CONF_GAIN_128;
	}
	
    else if(vote_range ==VOT_200MV)
	{
		strcpy(VOT_RANGE_DISP,"200mV");
//		oldRegValue = AD7190_GetRegisterValue(AD7190_REG_MODE,3, 1);   //�����ٶ�
		switch (speed_mode)
		{
			case SPEED_MODE_H: 
				{speed_x = 1;break; }
			case SPEED_MODE_M:
				{speed_x = 96;break; }
			case SPEED_MODE_L:
				{speed_x = 1023;break; }
			default:
				{speed_x = speed_mode;break; }
		}
		gain_mode = AD7190_CONF_GAIN_8;
	}
    else 
	{
		strcpy(VOT_RANGE_DISP,"2V   ");
//		oldRegValue = AD7190_GetRegisterValue(AD7190_REG_MODE,3, 1);   //�����ٶ�
		switch (speed_mode)
		{
			case SPEED_MODE_H: 
				{speed_x = 1;break; }
			case SPEED_MODE_M:
				{speed_x = 96;break; }
			case SPEED_MODE_L:
				{speed_x = 1023;break; }
			default:
				{speed_x = speed_mode;break; }
		}
		gain_mode = AD7190_CONF_GAIN_1;
	}
	    oldRegValue = oldRegValue &  ~0x3FF;
		newRegValue = oldRegValue | filter;

		AD7190_SetRegisterValue(AD7190_REG_MODE,newRegValue,3, 1);
	 	oldRegValue = AD7190_GetRegisterValue(AD7190_REG_MODE,3, 1); 
	

        AD7190_RangeSetup(1, gain_mode);
		AD7190_ChannelSelect(ch);

		if( times ==1)
		{
			resulttemp = AD7190_SingleConversion(speed_x);
		}
		else
		{
			resulttemp = AD7190_ContinuousReadAvg(speed_x,times);
		}
//      	      oldRegValue = AD7190_GetRegisterValue(AD7190_REG_MODE,3, 1);;
//		      SendUart(oldRegValue>>16);SendUart(oldRegValue>>8);SendUart(oldRegValue); SendUart(0XAA);

      return  resulttemp;
}
 void displaycode()
{
	switch ( speed_x)
{
	case 1023:
	{
		strcpy(SAMPLE_RATE_DISP , " 1.2/S" );
		break;
	}
	case 640:
	{
		strcpy(SAMPLE_RATE_DISP , " 1.8/S" );
		break;
	}
	case 480:
	{
		strcpy(SAMPLE_RATE_DISP , " 2.5/S" );
		break;
	}
	case 96:
	{
		strcpy(SAMPLE_RATE_DISP , "12.5/S" );
		break;
	}
	case 80:
	{
		strcpy(SAMPLE_RATE_DISP , "  15/S" );
		break;
	}
	case 32:
	{
		strcpy(SAMPLE_RATE_DISP , "  37/S" );
		break;
	}
	case 16:
	{
		strcpy(SAMPLE_RATE_DISP , "  75/S" );
		break;
	}
	case 5:
	{
		strcpy(SAMPLE_RATE_DISP , " 240/S" );
		break;
	}
	case 2:
	{
		strcpy(SAMPLE_RATE_DISP , " 600/S" );
		break;
	}
	case 1:
	{
		strcpy(SAMPLE_RATE_DISP , "1200/S" );
		break;
	}
	default:
		break;
}
//	speed_x
}
void int2str(unsigned long i,unsigned char *s,unsigned char len)
{
	unsigned char t=0;
	 for(t=0;t<len;t++)
	{
		s[len-1] = (i%10)+'0';
		i=i/10;
		s--;
	}
}

void int2voltage(unsigned long i,unsigned char *p,unsigned char len,unsigned char point)
{
	unsigned char *s;
	unsigned char t=0;
	s=p;

	 for(t=0;t<len;t++)
	{
		s[len-1] = (i%10)+'0';
		i=i/10;
		s--;
	}
	s = p;
	for(t=len;t>point;t--)
	{
		s[t] = s[t-1];
	}
	 s[t]='.';
}


void UartdispReg ()
{
	unsigned char s[8]="        ";
//	unsigned int h,l,m;
	unsigned long regtemp;
	regtemp = AD7190_GetRegisterValue(AD7190_REG_MODE,3, 1); 
	int2str(regtemp,s,8) ;
	printf("AD7190_REG_MODE: %s \n",s);
	regtemp = AD7190_GetRegisterValue(AD7190_REG_CONF,3, 1); 
	int2str(regtemp,s,8) ;
	printf("AD7190_REG_CONF: %s \n",s);
	regtemp = AD7190_GetRegisterValue(AD7190_REG_OFFSET,3, 1); 
	int2str(regtemp,s,8) ;
	printf("AD7190_REG_OFFSET: %s \n",s);
	regtemp = AD7190_GetRegisterValue(AD7190_REG_FULLSCALE,3, 1); 
	int2str(regtemp,s,8) ;
	printf("  REG_FULLSCALE: %s \n\n\n",s);

//	printf("speed1 = %d",speed1);

}

void keyscan()
{
	static unsigned char temp2 ; 
	 	if(key1==0)
			speed1 =  SPEED_MODE_H;
		else if(key2==0)
			speed1 =  SPEED_MODE_M;
		else 
			speed1 =  SPEED_MODE_L;
		if(key3==0)
		{
			vote_range =VOT_20MV;
			
		}
		else if(key4==0)
		{
			vote_range =VOT_200MV;
		}
		else 
		{
			vote_range =VOT_2000MV;
		}
		if(temp2!= vote_range)
		{
			AD7190_Calibrate(AD7190_MODE_CAL_INT_ZERO, AD7190_CH_AIN1P_AINCOM);
			AD7190_Calibrate(AD7190_MODE_CAL_INT_FULL, AD7190_CH_AIN1P_AINCOM);
			temp2= vote_range;
		}

		if(key5==0)
		{
			strcpy(CALIBRARE_DISP,"Calibrating..."); lcd_display();

			AD7190_Calibrate(AD7190_MODE_CAL_SYS_ZERO, AD7190_CH_AIN1P_AINCOM);
			strcpy(CALIBRARE_DISP,"CAL SYS_ZERO OK"); lcd_display();

			while(key5==0);
		}
		if(key6==0)
		{
			strcpy(CALIBRARE_DISP,"Calibrating..."); lcd_display();
			 AD7190_Calibrate(AD7190_MODE_CAL_SYS_FULL, AD7190_CH_AIN1P_AINCOM);
			strcpy(CALIBRARE_DISP,"CAL SYS_FULL OK"); lcd_display();
			while(key6==0) ;
		}
		if(key7==0)
		{
			strcpy(CALIBRARE_DISP,"Calibrating..."); lcd_display();
			AD7190_Calibrate(AD7190_MODE_CAL_INT_ZERO, AD7190_CH_AIN1P_AINCOM);
			strcpy(CALIBRARE_DISP,"CAL INT_ZERO OK"); lcd_display();
			while(key7==0);
		}
		if(key8==0)
		{
			strcpy(CALIBRARE_DISP,"Calibrating..."); lcd_display();
			 AD7190_Calibrate(AD7190_MODE_CAL_INT_FULL, AD7190_CH_AIN1P_AINCOM);
			strcpy(CALIBRARE_DISP,"CAL INT_FULL OK"); lcd_display();
			while(key8==0) ;
		}

}

/***************************************************************************//**
 * @brief Set device to idle or power-down.
 *
 * @param pwrMode - Selects idle mode or power-down mode.
 *                  Example: 0 - power-down
 *                           1 - idle
 *
 * @return none.
*******************************************************************************/
void AD7190_SetPower(unsigned char pwrMode)
{
     unsigned long oldPwrMode = 0x0;
     unsigned long newPwrMode = 0x0; 
         ADI_CS_LOW;

     oldPwrMode = AD7190_GetRegisterValue(AD7190_REG_MODE, 3, 1);
     oldPwrMode &= ~(AD7190_MODE_SEL(0x7));
     newPwrMode = oldPwrMode | 
                  AD7190_MODE_SEL((pwrMode * (AD7190_MODE_IDLE)) |
                                  (!pwrMode * (AD7190_MODE_PWRDN)));
     AD7190_SetRegisterValue(AD7190_REG_MODE, newPwrMode, 3, 1);
//	    ADI_CS_HIGH;

}
/***************************************************************************//**
 * @brief Selects the polarity of the conversion and the ADC input range.
 *
 * @param polarity - Polarity select bit. 
                     Example: 0 - bipolar operation is selected.
                              1 - unipolar operation is selected.
* @param range - Gain select bits. These bits are written by the user to select 
                 the ADC input range.     
 *
 * @return none.
*******************************************************************************/
void AD7190_RangeSetup(unsigned char polarity, unsigned char range)
{
    unsigned long oldRegValue = 0x0;
    unsigned long newRegValue = 0x0;
    ADI_CS_LOW;
    oldRegValue = AD7190_GetRegisterValue(AD7190_REG_CONF,3, 1);
    oldRegValue &= ~(AD7190_CONF_UNIPOLAR |
                     AD7190_CONF_GAIN(0x7)) ;
    newRegValue = oldRegValue | 
                  (polarity * AD7190_CONF_UNIPOLAR) |
                  AD7190_CONF_GAIN(range)|
					AD7190_CONF_CHOP; 
    AD7190_SetRegisterValue(AD7190_REG_CONF, newRegValue, 3, 1);
//	ADI_CS_HIGH;
//		SPISS = 1; 

}

/***************************************************************************//**
 * @brief Returns the result of a single conversion.
 *
 * @return regData - Result of a single analog-to-digital conversion.
*******************************************************************************/
unsigned long AD7190_SingleConversion(unsigned long speedx)
{
    unsigned long command = 0x0;
    unsigned long regData = 0x0;
 
    command = AD7190_MODE_SEL(AD7190_MODE_SINGLE) | 
              AD7190_MODE_CLKSRC(AD7190_CLK_INT) |
              AD7190_MODE_RATE( speedx);    
    ADI_CS_LOW;
    AD7190_SetRegisterValue(AD7190_REG_MODE, command, 3, 0); // CS is not modified.
    AD7190_WaitRdyGoLow() ;

    regData = AD7190_GetRegisterValue(AD7190_REG_DATA, 3, 0);
    ADI_CS_HIGH;
    
    return(regData);
}

/***************************************************************************//**
 * @brief Returns the average of several conversion results.
 *
 * @return samplesAverage - The average of the conversion results.
*******************************************************************************/
unsigned long AD7190_ContinuousReadAvg(unsigned long speedx,unsigned char sampleNumber)
{
    unsigned long samplesAverage = 0x0;
    unsigned char count = 0x0;
    unsigned long command = 0x0;
    
    command = AD7190_MODE_SEL(AD7190_MODE_CONT) | 
              AD7190_MODE_CLKSRC(AD7190_CLK_INT) |
              AD7190_MODE_RATE(speedx);
    ADI_CS_LOW;
    AD7190_SetRegisterValue(AD7190_REG_MODE, command, 3, 0); // CS is not modified.
    for(count = 0;count < sampleNumber;count ++)
    {
//		lcd_piontFlash();

        AD7190_WaitRdyGoLow();
        samplesAverage += AD7190_GetRegisterValue(AD7190_REG_DATA, 3, 0); // CS is not modified.
    }
    ADI_CS_HIGH;
    samplesAverage = samplesAverage / sampleNumber;
    
    return(samplesAverage);
}
/***************************************************************************//**
 * @brief Read data from temperature sensor and converts it to Celsius degrees.
 *
 * @return temperature - Celsius degrees.
*******************************************************************************/
unsigned long AD7190_TemperatureRead(void)
{
    unsigned char temperature = 0x0;
    unsigned long dataReg = 0x0;
     ADI_CS_LOW;
    AD7190_RangeSetup(0, AD7190_CONF_GAIN_1);
    AD7190_ChannelSelect(AD7190_CH_TEMP_SENSOR);
    dataReg = AD7190_SingleConversion(96);
    dataReg -= 0x800000;
    dataReg /= 2815;   // Kelvin Temperature
    dataReg -= 273;    //Celsius Temperature
    temperature = (unsigned long) dataReg;
//    ADI_CS_HIGH;
    return(temperature);
}
/***************************************************************************//**
 * @brief Selects the channel to be enabled.
 *
 * @param channel - Selects a channel. 0~7
 *  
 * @return none.
*******************************************************************************/
void AD7190_ChannelSelect(unsigned short channel)
{
     unsigned long oldRegValue = 0x0;
     unsigned long newRegValue = 0x0;   
    ADI_CS_LOW; 
    oldRegValue = AD7190_GetRegisterValue(AD7190_REG_CONF, 3, 1);
    oldRegValue &= ~(AD7190_CONF_CHAN(0xFF));
    newRegValue = oldRegValue | AD7190_CONF_CHAN(1 << channel);   
    AD7190_SetRegisterValue(AD7190_REG_CONF, newRegValue, 3, 1);
//	ADI_CS_HIGH;
}

/***************************************************************************//**
 * @brief Writes data into a register.
 *
 * @param registerAddress - Address of the register.
 * @param registerValue - Data value to write.
 * @param bytesNumber - Number of bytes to be written.
 * @param modifyCS - Allows Chip Select to be modified.
 *
 * @return none.
*******************************************************************************/
void AD7190_SetRegisterValue(unsigned char registerAddress,
                             unsigned long registerValue,
                             unsigned char bytesNumber,
                             unsigned char modifyCS)
{
    static unsigned char writeCommand[5] = {0, 0, 0, 0, 0};
    unsigned char* dataPointer    = registerValue;
    unsigned char bytesNr         = bytesNumber + 1;
    ADI_CS_LOW;
    writeCommand[0] = 0x01 * modifyCS;
    writeCommand[1] = AD7190_COMM_WRITE |
                      AD7190_COMM_ADDR(registerAddress);
    while(bytesNr > 1)
    {
        writeCommand[bytesNr] = registerValue;
		registerValue>>=8;
		bytesNr --;

		
    }
//	ADI_CS_HIGH;
    SPI_Write(writeCommand+1, bytesNumber +1 );
}

/***************************************************************************//**
 * @brief Waits for RDY pin to go low.
 *
 * @return none.
*******************************************************************************/
void AD7190_WaitRdyGoLow(void)
{
//	unsigned char dat = 0x01;
	unsigned char d1=0,d2=0;
//	for(d1=0;d1<100;d1++)
//	{
//			for(d2=0;d2<100;d2++) ;

//	}
	while( AD7190_RDY_STATE )
    {
    	lcd_piontFlash();
    }
}

/***************************************************************************//**
 * @brief Performs the given calibration to the specified channel. ִ�и�����У׼��ָ����ͨ����
 *
 * @param mode - Calibration type.
 * @param channel - Channel to be calibrated.
 *
 * @return none.
*******************************************************************************/
void AD7190_Calibrate(unsigned char mode, unsigned char channel)    /// 
{
    unsigned long oldRegValue = 0x0;
    unsigned long newRegValue = 0x0;
    
    AD7190_ChannelSelect(channel);
    oldRegValue = AD7190_GetRegisterValue(AD7190_REG_MODE, 3, 1);
    oldRegValue &= ~AD7190_MODE_SEL(0x7);
    newRegValue = oldRegValue | AD7190_MODE_SEL(mode)|AD7190_MODE_RATE( 1023);
    ADI_CS_LOW; 
    AD7190_SetRegisterValue(AD7190_REG_MODE, newRegValue, 3, 0); // CS is not modified.
    AD7190_WaitRdyGoLow();
//    ADI_CS_HIGH;
}

 /***************************************************************************//**
 * @brief Reads the value of a register.
 *
 * @param registerAddress - Address of the register.
 * @param bytesNumber - Number of bytes that will be read.
 * @param modifyCS    - Allows Chip Select to be modified.
 *
 * @return buffer - Value of the register.
*******************************************************************************/
unsigned long AD7190_GetRegisterValue(unsigned char registerAddress,
                                      unsigned char bytesNumber,
                                      unsigned char modifyCS)
{
	unsigned char TregisterWord[5] = {0, 0, 0, 0, 0}; 
    static unsigned char RregisterWord[5] = {0, 0, 0, 0, 0}; 
    unsigned long buffer          = 0x0;
    unsigned char i               = 0;
    ADI_CS_LOW;
    TregisterWord[0] = 0x01 * modifyCS;
    TregisterWord[1] = AD7190_COMM_READ |
                      AD7190_COMM_ADDR(registerAddress);
    TregisterWord[2] = 0x00;
    TregisterWord[3] = 0x00;
	
    SPI_Read(TregisterWord+1,RregisterWord, bytesNumber + 1);
    for(i = 1;i < bytesNumber + 1;i ++) 
    {
        buffer = (buffer << 8) + RregisterWord[i];
    }
    return(buffer);
}
/***************************************************************************//**
 * @brief Checks if the AD7190 part is present.
 *
 * @return status - Indicates if the part is present or not.
*******************************************************************************/
unsigned char AD7190_Init(void)
{
    unsigned char status = 1;
    unsigned char regVal = 0;
    
    AD7190_Reset();
	ADI_CS_LOW;
    regVal = AD7190_GetRegisterValue(AD7190_REG_ID, 1, 1);
	    SendUart( regVal  );

    if( (regVal & AD7190_ID_MASK)  != ID_AD7190)
    {
        status = 0;
    }
//	ADI_CS_HIGH;
    return(status);
}

/***************************************************************************//**
 * @brief Resets the device.
 *
 * @return none.
*******************************************************************************/
void AD7190_Reset(void)         //datasheet P30
{
    unsigned char registerWord[7] = {0};
    ADI_CS_LOW;
    registerWord[0] = 0xff;
    registerWord[1] = 0xFF;
    registerWord[2] = 0xFF;
    registerWord[3] = 0xFF;
    registerWord[4] = 0xFF;
    registerWord[5] = 0xFF;
    registerWord[6] = 0xFF;
    SPI_Write(registerWord, 6);
	ADI_CS_HIGH;
}
void InitUart()
{
    SCON = 0x5a;                //���ô���Ϊ8λ�ɱ䲨����
    T2L = (65536 - (FOSC/4/BAUD));                 //���ò�������װֵ
    T2H = (65536 - (FOSC/4/BAUD))>>8;                 //115200 bps(65536-18432000/4/115200)
    AUXR = 0x14;                //T2Ϊ1Tģʽ, ��������ʱ��2
    AUXR |= 0x01;               //ѡ��ʱ��2Ϊ����1�Ĳ����ʷ�����
}

///////////////////////////////////////////////////////////

void InitSPI()
{
    SPDAT = 0;                  //��ʼ��SPI����
    SPSTAT = SPIF | WCOL;       //���SPI״̬λ
    SPCTL = SSIG | SPEN | MSTR | CPOL |CPHA| SPDH;        //����ģʽ
}

///////////////////////////////////////////////////////////

void SendUart(unsigned char dat)
{
    while (!TI);                //�ȴ��������
    TI = 0;                     //������ͱ�־
    SBUF = dat;                 //���ʹ�������
}

///////////////////////////////////////////////////////////

unsigned char RecvUart()
{
    while (!RI);                //�ȴ��������ݽ������
    RI = 0;                     //������ձ�־
    return SBUF;                //���ش�������
}

///////////////////////////////////////////////////////////

unsigned char SPISwap(unsigned char dat)
{
	{
		SPDAT = dat;                //����SPI��������
		while (!(SPSTAT & SPIF));   //�ȴ��������
		SPSTAT = SPIF | WCOL;       //���SPI״̬λ
	}
    return SPDAT;               //����SPI����
}
//unsigned char SPI_Write(unsigned char *dat,unsigned char length)
//{
//	unsigned char i=0;
////    ADI_CS_LOW; 

//	for(i = 0;i<length;i++)
//	{
//		SPDAT = *dat;                //����SPI��������
//		while (!(SPSTAT & SPIF));   //�ȴ��������
//		SPSTAT = SPIF | WCOL;       //���SPI״̬λ
//		dat++;
//	}
////	ADI_CS_HIGH;
//    return SPDAT;               //����SPI����
//}

unsigned char SPI_Read(unsigned char *dat,unsigned char *RecDat,
                       unsigned char bytesNumber)
{						   
unsigned char i=0;
unsigned char ReadData[5]	= {0, 0, 0, 0, 0};	
//ADI_CS_LOW;
     for(i = 0;i<bytesNumber;i++)
	{
		SPDAT = *dat;                //����SPI��������
		while (!(SPSTAT & SPIF));   //�ȴ��������
		SPSTAT = SPIF | WCOL;       //���SPI״̬λ
		RecDat[i] = SPDAT;          //����
		dat++;
	}
//	ADI_CS_HIGH;
    return i;
}