#ifndef __LED_H
#define __LED_H

#include "stm32f0xx.h"

#define  PWR_LED_GPIO      GPIOA
#define  PWR_LED_PIN       GPIO_Pin_5

#define  SIM_LED_GPIO      GPIOA
#define  SIM_LED_PIN       GPIO_Pin_4

#define  SCAN_LED_GPIO      GPIOA
#define  SCAN_LED_PIN       GPIO_Pin_0

#define  TCP_LED_GPIO      GPIOA
#define  TCP_LED_PIN       GPIO_Pin_1

#define LED_OFF                       GPIOB->BSRR = 0x02
#define LED_ON                        GPIOB->BRR = 0x02 
#define LED_TURN                      GPIOB->ODR ^= 0x02

#define PwrLED_Set( )			  GPIO_SetBits(PWR_LED_GPIO, PWR_LED_PIN)//SPI_SCK = 1		//????
#define PwrLED_Clear( )			GPIO_ResetBits(PWR_LED_GPIO, PWR_LED_PIN)//SPI_SCK = 0		//????

#define SIMLED_Set( )			  GPIO_SetBits(SIM_LED_GPIO, SIM_LED_PIN)//SPI_SCK = 1		//????
#define SIMLED_Clear( )			GPIO_ResetBits(SIM_LED_GPIO, SIM_LED_PIN)//SPI_SCK = 0		//????

#define SCANLED_Set( )			GPIO_SetBits(SCAN_LED_GPIO, SCAN_LED_PIN)//SPI_SCK = 1		//????
#define SCANLED_Clear( )		GPIO_ResetBits(SCAN_LED_GPIO, SCAN_LED_PIN)//SPI_SCK = 0		//????

#define TCPLED_Set( )			  GPIO_SetBits(TCP_LED_GPIO, TCP_LED_PIN)//SPI_SCK = 1		//????
#define TCPLED_Clear( )			GPIO_ResetBits(TCP_LED_GPIO, TCP_LED_PIN)//SPI_SCK = 0		//????

void LED_Init(void);

#endif
