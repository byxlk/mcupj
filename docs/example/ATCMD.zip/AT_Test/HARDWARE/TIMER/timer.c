#include "timer.h"
#include "string.h"
#include <stdlib.h>    //�ַ�ת����ͷ�ļ�
#include "USART2.h"
#include "USART1.h"

unsigned int tim_buff[TIM_MAX];
unsigned char Timer3_flag=0;
unsigned char tim_connect=0;
unsigned int check_Timer(unsigned char tim_id)
{
 return tim_buff[tim_id];
}

//psc:900-1   per:889 tim:1s  
void TIM3_Init(void)                                                          //10ms????
{   
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  NVIC_InitTypeDef NVIC_InitStructure;

  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

  NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
 

  TIM_TimeBaseStructure.TIM_Period = 9;           // �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) (48Mhz)
  //TIM_TimeBaseStructure.TIM_Prescaler = (18000 - 1);	//ʱ��Ԥ��Ƶ�� 
	TIM_TimeBaseStructure.TIM_Prescaler = (9000 - 1);
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;			//���ϼ���ģʽ
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

  TIM_ClearFlag(TIM3, TIM_FLAG_Update);			        // �������жϱ�־ 
  TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
  TIM_Cmd(TIM3, ENABLE);
}

void TIM3_NVIC(FunctionalState NewState)
{
	TIM_Cmd(TIM3, NewState);
}

void TIM3_IRQHandler(void)   //�жϺ���
{
  if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
  {
   TIM_ClearITPendingBit(TIM3,TIM_FLAG_Update);
	 
	 Timer3_flag|=TIM_FLG_10MS;   
	 if(tim_buff[AT_TIMER_ID]>1) tim_buff[AT_TIMER_ID]--;
	 else if(tim_buff[AT_TIMER_ID]==1){
   tim_buff[AT_TIMER_ID]=0;
	 Timer3_flag|=TIM_FLG_AT_TIMEROUT;
	 }
	 if(tim_buff[SEV_USART_TIER]>1) tim_buff[SEV_USART_TIER]--;
	 else if(tim_buff[SEV_USART_TIER]==1){
   tim_buff[SEV_USART_TIER]=0;
   USART2_STA.USART_RX_STA|=0x8000;   //���ս���
	 }
	 if(tim_buff[IP_COM_USART_TIM]>1) tim_buff[IP_COM_USART_TIM]--;
	 else if(tim_buff[IP_COM_USART_TIM]==1){
   tim_buff[IP_COM_USART_TIM]=0;
   USART1_STA.USART_RX_STA|=0x8000;   //���ս���
	 }
	 
	 tim_connect=0;
	}
}





