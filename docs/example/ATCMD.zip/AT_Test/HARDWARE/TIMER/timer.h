#ifndef __TIMER_H
#define __TIMER_H
#include <stdint.h>
#include "stm32f0xx_tim.h"

#define TIM_MAX         4
#define AT_TIMER_ID     0
#define SEV_USART_TIER  1
#define IP_COM_USART_TIM 2

#define STAR_AT_TIMER_TIMER(x)         tim_buff[AT_TIMER_ID]=x+2
#define STOP_AT_TIMER_TIMER            tim_buff[AT_TIMER_ID]=0
#define STAR_SEV_USART_TIMER(x)        tim_buff[SEV_USART_TIER]=x+2
#define STOP_SEV_USART_TIMER_TIMER     tim_buff[SEV_USART_TIER]=0

#define STAR_IP_COM_USART_TIMER(x)     tim_buff[IP_COM_USART_TIM]=x+2
#define STOP_IP_COM_USART_TIMER        tim_buff[IP_COM_USART_TIM]=0

#define TIM_FLG_AT_TIMEROUT  0x80
#define TIM_FLG_1MS          0x40
#define TIM_FLG_10MS         0x20
extern unsigned int tim_buff[TIM_MAX];
extern unsigned char Timer3_flag;
void TIM3_Init(void);  
void TIM3_NVIC(FunctionalState NewState);
unsigned int check_Timer(unsigned char tim_id);
#endif





