#include "LED.h"

void LED_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  /* ʹ��GPIOBʱ�� */
  //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

  /* ����LED��Ӧ����PB1*/ 
	
  GPIO_InitStructure.GPIO_Pin = PWR_LED_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(PWR_LED_GPIO, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = SIM_LED_PIN;
  GPIO_Init(SIM_LED_GPIO, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = SCAN_LED_PIN;
  GPIO_Init(SCAN_LED_GPIO, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = TCP_LED_PIN;
  GPIO_Init(TCP_LED_GPIO, &GPIO_InitStructure);
	PwrLED_Clear();
	SIMLED_Set();
	SCANLED_Set();
	TCPLED_Set();
	
}
