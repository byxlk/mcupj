#include "stm32f0xx.h"
#include "delay.h"
#include "led.h"
#include "USART1.h"
#include "stm32f0xx_gpio.h"
#include "USART1.h"
#include "timer.h"
#include "delay.h"
#include "stdio.h"
#include "atcode.h"
#include "USART2.h"

unsigned char Encoding_Dat(unsigned char* p)  
{
 p[0]=0xEC;
 p[1]= 0;
 p[2]= 1;
 p[3]= 2;
 p[4]= 3;
 p[5]= 4;
 p[6]= 5;
 p[7]= 6;                        
 return 8;
}

int main(void)
{
	static unsigned int tcp_send_timer=0;
	static unsigned char tcp_send_buff[100];
	unsigned char tcp_data_len;
	
  //delay_init();
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);  
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOF, ENABLE);
	TIM3_Init();                           //����10ms��ʱ��
  USART2_Init(115200);
	AT_Mode_Init();                        //SIM800c��ʼ��
	LED_Init();                            //LED��ʼ��
  while (1)
  {			
		if(Timer3_flag&TIM_FLG_AT_TIMEROUT)   //ATָ�ʱ
		{
	   AT_Mode_Correct_Timeout();           //ִ�г�ʱ����
		 Timer3_flag&=~TIM_FLG_AT_TIMEROUT;
	  }
		
		if(Timer3_flag&TIM_FLG_10MS)          //10msʱ�䵽
		{
		 tcp_send_timer++;
	   Timer3_flag&=~TIM_FLG_10MS;
	  }
		
		if(USART2_STA.USART_RX_STA&0x8000)   //�����յ�����
		{
		 USART2_STA.USART_RX_BUF[USART2_STA.USART_RX_STA&0x3fff]='\0'; //���������
	   AT_Mode_Correct_Check(USART2_STA.USART_RX_BUF);               //��������
		 USART2_STA.USART_RX_STA=0;
	  }
		
		if(SIM800C_AT_COM.tcp_connect==SIM800C_TCP_CONNECT)           //TCP�Ѿ�����
		{
	   if((tcp_send_timer>=300)&&AT_Mode_Check_Work_Sta()==0)       //ģ������򷢳�����
		 {
		  tcp_data_len=Encoding_Dat(tcp_send_buff);
			AT_Mode_TCP_Sned(tcp_send_buff,tcp_data_len);     
			tcp_send_timer=0;
		 }		 
    	TCPLED_Clear();                                            //TCP���ӽ��������LED
	  }else  TCPLED_Set();	                                       //Ϩ��LED
   }
}

#ifdef  USE_FULL_ASSERT

void assert_failed(uint8_t* file, uint32_t line)
{

  while (1)
  {
  }
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
