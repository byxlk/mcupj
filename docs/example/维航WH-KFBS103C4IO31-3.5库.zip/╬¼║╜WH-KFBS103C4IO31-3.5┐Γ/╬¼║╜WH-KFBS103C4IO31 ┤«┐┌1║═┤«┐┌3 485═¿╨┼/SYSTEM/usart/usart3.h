#ifndef __USART3_H
#define __USART3_H
#include "stdio.h"	
#include "sys.h" 
void uart3_init(u32 bound);
void uart3_dma_send_enable(uint16_t size);
#endif


