#ifndef __USART2_H
#define __USART2_H
#include "stdio.h"	
#include "sys.h" 
 
void USART2_Init(u32 My_BaudRate);
void RS485_Receive2_Data(u8 *buf,u8 *len);
#endif


