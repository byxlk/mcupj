#include "can.h"
#include "delay.h"
#include "usart.h"
#include "sys.h"
#include "control.h"	
CanRxMsg CAN1_RxMessage;
u8 CAN1_CanRxMsgFlag=0;
void (*callbackCan)(void);
typedef  struct {
  unsigned char   SJW;
  unsigned char   BS1;
  unsigned char   BS2;
  unsigned short  PreScale;
} tCAN_BaudRate;
tCAN_BaudRate  CAN_BaudRateInitTab[]= {      // CLK=36MHz
   {CAN_SJW_1tq,CAN_BS1_10tq,CAN_BS2_1tq,3},     // 1M
   {CAN_SJW_1tq,CAN_BS1_8tq,CAN_BS2_1tq,4},     // 900K
   {CAN_SJW_2tq,CAN_BS1_13tq,CAN_BS2_1tq,13},     // 800K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,3},     // 666K
   {CAN_SJW_1tq,CAN_BS1_13tq,CAN_BS2_1tq,4},     // 600K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,4},     // 500K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,5},     // 400K
   {CAN_SJW_1tq,CAN_BS1_15tq,CAN_BS2_1tq,7},    // 300K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,8},    // 250K
   {CAN_SJW_1tq,CAN_BS1_14tq,CAN_BS2_1tq,10},	// 225K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,10},    // 200K
   {CAN_SJW_1tq,CAN_BS1_13tq,CAN_BS2_1tq,15},	// 160K
   {CAN_SJW_1tq,CAN_BS1_14tq,CAN_BS2_1tq,15},    // 150K
   {CAN_SJW_1tq,CAN_BS1_8tq,CAN_BS2_1tq,25},	// 144K
   {CAN_SJW_1tq,CAN_BS1_6tq,CAN_BS2_1tq,36},   // 125K
   {CAN_SJW_1tq,CAN_BS1_13tq,CAN_BS2_1tq,20},	// 120K
   {CAN_SJW_1tq,CAN_BS1_6tq,CAN_BS2_1tq,45},    // 100K
   {CAN_SJW_1tq,CAN_BS1_14tq,CAN_BS2_1tq,25},   // 90K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,25},   // 80K
   {CAN_SJW_1tq,CAN_BS1_14tq,CAN_BS2_1tq,30},	// 75K
   {CAN_SJW_1tq,CAN_BS1_13tq,CAN_BS2_1tq,40},    // 60K
   {CAN_SJW_1tq,CAN_BS1_14tq,CAN_BS2_1tq,45},    // 50K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,50},    // 40K
   {CAN_SJW_1tq,CAN_BS1_14tq,CAN_BS2_1tq,75},   // 30K
   {CAN_SJW_1tq,CAN_BS1_16tq,CAN_BS2_1tq,100},   // 20K
};
/**
  * @brief  ??????????????????
  * @param  BaudRate CAN?????,???bps
  * @retval ?????????
  */
uint32_t CAN_GetBaudRateNum(uint32_t BaudRate)
{
    switch(BaudRate){
        case 1000000 :return 0;
        case 900000 :return 1;
        case 800000 :return 2;
        case 666000 :return 3;
        case 600000 :return 4;
        case 500000 :return 5;
        case 400000 :return 6;
        case 300000 :return 7;
        case 250000 :return 8;
        case 225000:return 9;
        case 200000 :return 10;
        case 160000:return 11;
        case 150000 :return 12;
        case 144000:return 13;
        case 125000 :return 14;
        case 120000:return 15;
        case 100000 :return 16;
        case 90000 :return 17;
        case 80000 :return 18;
        case 75000:return 19;
        case 60000 :return 20;
        case 50000 :return 21;
        case 40000 :return 22;
        case 30000 :return 23;
        case 20000 :return 24;
        default:return 0;
    }
}
//CAN��ʼ��
//tsjw:����ͬ����Ծʱ�䵥Ԫ.��Χ:CAN_SJW_1tq~ CAN_SJW_4tq
//tbs2:ʱ���2��ʱ�䵥Ԫ.   ��Χ:CAN_BS2_1tq~CAN_BS2_8tq;
//tbs1:ʱ���1��ʱ�䵥Ԫ.   ��Χ:CAN_BS1_1tq ~CAN_BS1_16tq
//brp :�����ʷ�Ƶ��.��Χ:1~1024; tq=(brp)*tpclk1
//������=Fpclk1/((tbs1+1+tbs2+1+1)*brp);
//mode:CAN_Mode_Normal,��ͨģʽ;CAN_Mode_LoopBack,�ػ�ģʽ;
//Fpclk1��ʱ���ڳ�ʼ����ʱ������Ϊ42M,�������CAN1_Mode_Init(CAN_SJW_1tq,CAN_BS2_6tq,CAN_BS1_7tq,6,CAN_Mode_LoopBack);
//������Ϊ:42M/((6+7+1)*6)=500Kbps
//����ֵ:0,��ʼ��OK;
//    ����,��ʼ��ʧ��; 


u8 CAN1_Mode_Init(uint32_t address,uint32_t baudRate,u8 mode)
{

	CAN_InitTypeDef        	CAN_InitStructure;
	CAN_FilterInitTypeDef  	CAN_FilterInitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	NVIC_InitTypeDef  		NVIC_InitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);//??CAN1??	
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); //ʹ�ܶ˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
    
  /* Configure CAN pin: TX */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	CAN_InitStructure.CAN_TTCM=DISABLE;			//?????????  
	CAN_InitStructure.CAN_ABOM=DISABLE;			//????????	 
	CAN_InitStructure.CAN_AWUM=DISABLE;			//??????????(??CAN->MCR?SLEEP?)
	CAN_InitStructure.CAN_NART=ENABLE;			//???????? 
	CAN_InitStructure.CAN_RFLM=DISABLE;		 	//?????,??????  
	CAN_InitStructure.CAN_TXFP=DISABLE;			//??????????? 
	CAN_InitStructure.CAN_Mode= mode;	        //????: mode:0,????;1,????; 
  CAN_InitStructure.CAN_SJW = CAN_BaudRateInitTab[CAN_GetBaudRateNum(baudRate)].SJW;//??????1M
  CAN_InitStructure.CAN_BS1 = CAN_BaudRateInitTab[CAN_GetBaudRateNum(baudRate)].BS1;
  CAN_InitStructure.CAN_BS2 = CAN_BaudRateInitTab[CAN_GetBaudRateNum(baudRate)].BS2;
  CAN_InitStructure.CAN_Prescaler = CAN_BaudRateInitTab[CAN_GetBaudRateNum(baudRate)].PreScale;
	
	CAN_Init(CAN1, &CAN_InitStructure);        	//???CAN1 
	CAN_FilterInitStructure.CAN_FilterNumber=0;	//???0
	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 	//?????
	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit; 	//32?? 
	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;	//32?ID
	CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;//32?MASK
	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;//???0???FIFO0
	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;//?????0
	CAN_FilterInit(&CAN_FilterInitStructure);			//??????
	
	CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);				//FIFO0????????.		
	
	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;     // ?????1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;            // ?????0
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	return 0;
	
}   

void CAN_AttachInterrupt(void (*callbackFun)(void))
{
	callbackCan=callbackFun;
}

//�жϷ�����			    
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  CAN_Receive(CAN1,CAN_FIFO0, &CAN1_RxMessage);
  CAN_ClearITPendingBit(CAN1,CAN_IT_FMP0);
  CAN1_CanRxMsgFlag = 1;
	if(callbackCan!=NULL) 
	(*callbackCan)();
}


u8 CAN_SendData(uint32_t StdId,uint32_t ExtId,u8 *buf,u8 len)
{	
	u8 mbox;
	int i=0; 
	CanTxMsg TxMessage;
	TxMessage.StdId=StdId;			
  TxMessage.IDE=CAN_Id_Standard; 	
	TxMessage.RTR=CAN_RTR_Data;		
	TxMessage.DLC=len;				
	memcpy(TxMessage.Data,buf,len);
	mbox= CAN_Transmit(CAN1, &TxMessage);   
	while((CAN_TransmitStatus(CAN1, mbox)==CAN_TxStatus_Failed)&&(i<0XFFF))i++;	
	if(i>=0XFFF)return 1;
	return 0;	 
}

short CAN_ReceiveCanRxMsg(CanRxMsg *RxMessage)
{		   		   
	if(CAN1_CanRxMsgFlag==0)return -1;		
	*RxMessage=CAN1_RxMessage;
	CAN1_CanRxMsgFlag=0;
	return RxMessage->DLC;
}

void CanSend(char id,char cmd,long pwm_value1, long pwm_value2,long pwm_value3, long pwm_value4,char size){
    u8 canbuf[8];
		canbuf[0]=cmd;
		if(size==2)
		{
			canbuf[1]=(pwm_value1>>8)&0xff;
			canbuf[2]=pwm_value1&0xff;
			canbuf[3]=(pwm_value2>>8)&0xff;
			canbuf[4]=pwm_value2&0xff;
			size=5;
		}else if(size==1)
		{
			canbuf[1]=(pwm_value1>>8)&0xff;
			canbuf[2]=pwm_value1&0xff;
			size=3;
		}
		else if(size==3)
		{
			canbuf[1]=(pwm_value1>>8)&0xff;
			canbuf[2]=pwm_value1&0xff;
			canbuf[3]=(pwm_value2>>8)&0xff;
			canbuf[4]=pwm_value2&0xff;
			canbuf[5]=(pwm_value3>>8)&0xff;
			canbuf[6]=pwm_value3&0xff;
			size=7;
		}else
		{
			canbuf[1]=(pwm_value1>>8)&0xff;
			canbuf[2]=pwm_value1&0xff;
			canbuf[3]=(pwm_value2>>8)&0xff;
			canbuf[4]=pwm_value2&0xff;
			canbuf[5]=(pwm_value3>>8)&0xff;
			canbuf[6]=pwm_value3&0xff;
			canbuf[7]=pwm_value4&0xff;
			size=8;
		}
		CAN_SendData(id,0,canbuf,size);
}

void CanSendData(){
    u8 canbuf[8];
		canbuf[0]=0x00;
		canbuf[1]=0x00;
		canbuf[2]=0x00;
		canbuf[3]=0x00;
		canbuf[4]=0x07;
		canbuf[5]=0x00;
		canbuf[6]=0xE0;
		canbuf[7]=0x00;
		CAN_SendData(0x48,0,canbuf,8);
}
void CanRecv()
{
	CanRxMsg RxMessage;
	CAN_ReceiveCanRxMsg(&RxMessage);
		
}





