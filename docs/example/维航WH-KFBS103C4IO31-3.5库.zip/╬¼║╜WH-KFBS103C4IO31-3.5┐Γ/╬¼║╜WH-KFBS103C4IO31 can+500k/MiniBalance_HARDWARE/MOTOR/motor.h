#ifndef __MOTOR_H
#define __MOTOR_H
#include <sys.h>	 
  /**************************************************************************

**************************************************************************/


#define PWMA   TIM3->CCR2  //PA6  ʵ�ʵ�·�Ե�   
#define AIN1   PBout(12) //1����ʱ��  ��ʱ��4 ��ֵ
#define AIN2   PBout(13)

#define BIN1   PBout(14) //1����ʱ��   ��ʱ��3 Ϊ��ֵ
#define BIN2   PBout(15)
#define PWMB   TIM3->CCR1  //PA7
void MiniBalance_PWM_Init(u16 arr,u16 psc);
void MiniBalance_Motor_Init(void);
void Timer1_Init(u16 arr,u16 psc);
#endif
