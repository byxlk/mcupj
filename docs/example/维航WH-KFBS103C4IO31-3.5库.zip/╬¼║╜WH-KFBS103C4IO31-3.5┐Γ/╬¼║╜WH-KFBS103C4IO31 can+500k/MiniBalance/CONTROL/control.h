#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
#define PI 3.14159265
#define ZHONGZHI 0
#define DIFFERENCE 100
extern	int Balance_Pwm,Velocity_Pwm,Turn_Pwm;
int task(void);
void Xianfu_Pwm(void);
void Get_Angle(u8 way);
int myabs(int a);
int Incremental_PI_A (int Encoder,float Target);
int Incremental_PI_B (int Encoder,float Target);
int Position_PID (int Encoder,int Target);
void PID_Adjust(int encoder);
void Set_Pwm(int motoA,int motoB);
void SendEncoder(void);
#endif
